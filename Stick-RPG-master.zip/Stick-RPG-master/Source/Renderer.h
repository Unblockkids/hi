#ifndef RENDERER_H_INCLUDED
#define RENDERER_H_INCLUDED

class Renderer : sf::RenderWindow
{
    public:
        void drawInBounds(sf::Drawable& drawable)
};

#endif // RENDERER_H_INCLUDED
