#include <iostream>

#include "Application.h"

int main()
{
    Application app("Stick RPG V0.1");
    app.runMainLoop();

    return 0;
}
