#include "SBase.h"

namespace State
{
    StateBase::StateBase(Application& app)
    :   m_pApplication  (&app)
    {

    }
}
