#ifndef SINGLETON_H_INCLUDED
#define SINGLETON_H_INCLUDED

class Singleton
{
    public:

    private:
        Singleton() = delete;
};

#endif // SINGLETON_H_INCLUDED
